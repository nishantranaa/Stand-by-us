package com.example.standbyus;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.provider.Settings;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    //private static int TOAST_DURATION;

    public static boolean start = false;
    public static boolean junior = false;
    public static boolean middle = false;
    public static boolean senior = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        //TOAST_DURATION = 1000;

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        /* Main message */
        Toast toast = Toast.makeText(this, "Welcome mate", Toast.LENGTH_SHORT);
        //toast.setDuration(TOAST_DURATION/10);
        toast.show();
        /* Settings message */
        Toast toastStart = Toast.makeText
                (this, "Enter a Username First", Toast.LENGTH_SHORT);

        Button startMain = findViewById(R.id.mainButton);
        // EditText new_username = findViewById(R.id.new_username);
        Intent intentJunior = new Intent(this, Junior.class);
        Intent intentMiddle = new Intent(this, Middle.class);
        Intent intentSenior = new Intent(this, Senior.class);
        Intent settings = new Intent(this, SetUp.class);

        startMain.setOnClickListener(new View.OnClickListener() {

            @Override

            public void onClick(View view) {

              // Log.i(">>>>>>>>>>>>",  userName);
               // userName = new_username.getText().toString();
                //userName.isEmpty())

                if (junior == true) {
                        startActivity(intentJunior);
                    } else if (middle == true) {
                        startActivity(intentMiddle);
                    } else {
                        startActivity(intentSenior);
                    }


                startActivity(settings);
                toastStart.show();
                }


        });


    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
    return false;
    }

}

